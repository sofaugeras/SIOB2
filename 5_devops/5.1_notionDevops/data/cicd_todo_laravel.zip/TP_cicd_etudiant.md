# TP — Déploiement CI/CD d'une application Laravel 🚀

## Informations

| | |
|---|---|
| **Durée** | 3h |
| **Prérequis** | Avoir suivi les TPs Docker précédents |
| **Repo de départ** | Forker le repo `lyceesaintsauveur/laravel-todo` |
| **URL de votre app** | `http://todo-VOTRE_PRENOM.srv-debian.local` |

---

## Étape 1 — Forker le projet 🍴

1. Connectez-vous à GitHub avec votre compte
2. Allez sur `https://github.com/lyceesaintsauveur/laravel-todo`
3. Cliquez sur **Fork** en haut à droite
4. Sélectionnez votre compte personnel comme destination
5. Clonez votre fork en local :

```bash
git clone https://github.com/VOTRE_USER/laravel-todo.git
cd laravel-todo
```

---

## Étape 2 — Créer un compte Docker Hub 🐳

1. Rendez-vous sur [hub.docker.com](https://hub.docker.com)
2. Créez un compte gratuit
3. Créez un **Access Token** :
   - Avatar → Account Settings → Security → **New Access Token**
   - Description : `github-actions`
   - Permissions : **Read & Write**
   - Copiez le token — il ne s'affiche qu'une fois !

---

## Étape 3 — Configurer les secrets GitHub 🔐

Dans votre repo GitHub → **Settings → Secrets and variables → Actions → New repository secret** :

| Nom du secret | Valeur |
|---|---|
| `DOCKERHUB_USERNAME` | Votre identifiant Docker Hub |
| `DOCKERHUB_TOKEN` | Le token généré à l'étape 2 |

---

## Étape 4 — Adapter les fichiers de configuration ✏️

### 4.1 Le fichier `ci-cd.yml`

Dans `.github/workflows/ci-cd.yml`, repérez les lignes avec `sofaugeras` et remplacez par votre identifiant Docker Hub :

```yaml
tags: |
  ${{ secrets.DOCKERHUB_USERNAME }}/todo-laravel:latest
  ${{ secrets.DOCKERHUB_USERNAME }}/todo-laravel:${{ github.sha }}
```

Ces lignes utilisent déjà le secret — **rien à modifier ici**.

Vérifiez que le job `deploy` contient bien :

```yaml
deploy:
  runs-on: self-hosted
```

### 4.2 Le fichier `.env.ci`

Vérifiez que le fichier `.env.ci` à la racine du projet contient les bonnes valeurs pour la CI :

```ini
APP_ENV=testing
APP_DEBUG=false
CACHE_DRIVER=array
SESSION_DRIVER=array
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=todo_test
DB_USERNAME=laravel_test
DB_PASSWORD=secret
```

---

## Étape 5 — Préparer le serveur 🖥️

!!! warning "Cette étape est réalisée par le professeur"
    Le professeur a déjà configuré sur `srv-debian` :

    - Le dossier `/opt/todo-VOTRE_PRENOM/` avec le fichier `.env.prod`
    - La config Nginx qui redirige `todo-VOTRE_PRENOM.srv-debian.local` → votre port
    - Le runner GitHub Actions de l'organisation `lyceesaintsauveur`

Vérifiez avec le professeur que votre dossier est prêt avant de continuer.

---

## Étape 6 — Premier déploiement 🚀

Commitez et poussez vos modifications sur la branche `main` :

```bash
git add .
git commit -m "feat: configuration CI/CD initiale"
git push origin main
```

Rendez-vous dans l'onglet **Actions** de votre repo GitHub. Vous devriez voir le pipeline démarrer avec deux jobs :

```
CI — Build & Tests  →  CD — Docker build & Deploy
```

### Surveiller le pipeline

- **Job CI** (~3 min) : installe les dépendances, lance les tests PHPUnit
- **Job CD** (~3 min) : build l'image Docker, la pousse sur Docker Hub, déploie sur srv-debian

!!! success "Pipeline vert ✅"
    Si les deux jobs affichent une coche verte, votre application est déployée !

!!! failure "Pipeline rouge ❌"
    Lisez le message d'erreur dans le job concerné. Les erreurs les plus fréquentes :

    - **CI échoue** → un test PHPUnit ne passe pas, vérifiez votre code
    - **CD échoue sur Docker Hub** → vérifiez vos secrets `DOCKERHUB_USERNAME` et `DOCKERHUB_TOKEN`
    - **CD échoue sur le deploy** → contactez le professeur

---

## Étape 7 — Tester l'application 🌐

Depuis un navigateur sur le réseau du lycée :

```
http://todo-VOTRE_PRENOM.srv-debian.local
```

Vous devriez être redirigé vers la page de connexion de l'application Todo.

Créez un compte via **Register** et testez les fonctionnalités.

---

## Étape 8 — Modifier et redéployer 🔄

Faites une modification dans le code — par exemple changez le titre de la page d'accueil dans `resources/views/home.blade.php`.

Commitez et poussez :

```bash
git add .
git commit -m "feat: modification du titre"
git push origin main
```

Observez le pipeline se déclencher automatiquement dans l'onglet Actions. Dans 5 à 6 minutes, votre modification sera visible sur `http://todo-VOTRE_PRENOM.srv-debian.local`.

---

## Questions de synthèse ❓

Répondez par écrit dans un fichier `REPONSES.md` à la racine de votre repo :

1. Quelle est la différence entre le job `CI` et le job `CD` ?
2. Pourquoi le job `deploy` utilise `runs-on: self-hosted` et non `runs-on: ubuntu-latest` ?
3. Pourquoi le fichier `.env.prod` n'est-il pas dans le repo GitHub ?
4. Que se passe-t-il si un test PHPUnit échoue ? L'application est-elle déployée ?
5. À quoi sert le `docker compose down` avant le `docker compose up` dans le script de déploiement ?
6. Expliquez le rôle de chacun des 3 conteneurs de la stack (`app`, `nginx`, `mysql`).

---

## Pour aller plus loin 🏆

Si vous avez terminé avant la fin du TP :

- Ajoutez une notification dans le pipeline (badge de status dans le `README.md`)
- Créez une branche `feature/ma-fonctionnalite`, faites une PR vers `main` et observez le CI se déclencher
- Modifiez le `Dockerfile` pour corriger le warning `gd` (ajouter `libpng16` dans le stage runtime)
