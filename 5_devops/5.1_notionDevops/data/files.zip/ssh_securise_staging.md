# Configuration SSH sécurisée pour le déploiement CD

> **Contexte** : Déploiement automatique de `laravel-todo` vers un serveur Debian bare-metal  
> **Niveau** : BTS — axe DevSecOps  
> **Prérequis** : Notions SSH de base, pipeline GitHub Actions existant

---

## 1. Pourquoi une configuration SSH dédiée ?

Par défaut, SSH autorise n'importe quel utilisateur disposant d'un mot de passe à se connecter. Pour un pipeline CI/CD, c'est inacceptable : GitHub Actions doit pouvoir se connecter **sans mot de passe**, avec des droits **strictement limités** à ce dont le déploiement a besoin.

Les trois principes appliqués ici :

| Principe | Traduction concrète |
|---|---|
| **Moindre privilège** | Un user `deploy` dédié, sans sudo global |
| **Authentification par clé** | Clé ED25519, mots de passe désactivés |
| **Surface d'attaque réduite** | Port SSH non standard, fail2ban, accès restreint |

---

## 2. Architecture de la connexion SSH CI/CD

![Architecture de la connexion SSH CI/CD](images/01_architecture_ssh.png)

Le runner GitHub Actions récupère la clé privée depuis les Secrets, ouvre une connexion SSH chiffrée vers le serveur Debian sur le port 2222. Le daemon `sshd` vérifie la clé publique dans `authorized_keys`, `fail2ban` surveille les tentatives suspectes, et l'utilisateur `deploy` — membre du groupe `docker` mais sans sudo — exécute le script de déploiement qui pilote la stack Docker Compose.

---

## 3. Sécurisation du daemon SSH (`sshd_config`)

### 3.1 Modifier la configuration

```bash
sudo nano /etc/ssh/sshd_config
```

Paramètres à modifier ou vérifier :

```ini
# ─── Port non standard ───────────────────────────────────────────
Port 2222                        # évite les scans automatiques sur 22

# ─── Authentification ────────────────────────────────────────────
PasswordAuthentication no        # CRITIQUE : désactiver les mots de passe
PubkeyAuthentication yes         # seules les clés sont acceptées
AuthorizedKeysFile .ssh/authorized_keys
PermitRootLogin no               # root ne peut jamais se connecter en SSH

# ─── Restrictions d'accès ────────────────────────────────────────
AllowUsers deploy                # seul l'user deploy est autorisé
MaxAuthTries 3                   # 3 tentatives max avant déconnexion
LoginGraceTime 20                # 20s pour s'authentifier

# ─── Protocole et chiffrement ────────────────────────────────────
Protocol 2                       # forcer SSH v2 (v1 est obsolète et vulnérable)
KexAlgorithms curve25519-sha256,diffie-hellman-group14-sha256
Ciphers chacha20-poly1305@openssh.com,aes256-gcm@openssh.com
MACs hmac-sha2-512,hmac-sha2-256

# ─── Autres durcissements ────────────────────────────────────────
X11Forwarding no                 # pas d'interface graphique distante
AllowTcpForwarding no            # pas de tunnel TCP
ClientAliveInterval 300          # déconnecte les sessions inactives (5 min)
ClientAliveCountMax 2
```

### 3.2 Valider et recharger

```bash
# Toujours tester la config avant de recharger
# (évite de se retrouver bloqué dehors si la config est invalide)
sudo sshd -t

# Si OK :
sudo systemctl reload sshd
```

> ⚠️ **Important pédagogique** : ne jamais recharger SSH sans avoir une session déjà ouverte en parallèle. Si la config est invalide et qu'on se déconnecte, on se retrouve dehors sans possibilité de se reconnecter.

### 3.3 Mettre à jour le pare-feu

```bash
# Autoriser le nouveau port
sudo ufw allow 2222/tcp comment "SSH CI/CD deploy"

# Supprimer l'ancien port si vous changiez
sudo ufw delete allow 22/tcp

sudo ufw status
```

---

## 4. Génération de la paire de clés ED25519

### Pourquoi ED25519 et pas RSA ?

![Comparaison RSA vs ED25519](images/02_rsa_vs_ed25519.png)

ED25519 est basé sur les courbes elliptiques de Bernstein. À sécurité équivalente, les clés sont beaucoup plus courtes, la génération plus rapide, et la résistance aux attaques quantiques futures meilleure. C'est le standard recommandé pour tout nouveau déploiement depuis 2019.

### 4.1 Génération sur la machine locale

```bash
# Générer une paire dédiée au pipeline (ne pas réutiliser votre clé perso)
ssh-keygen -t ed25519 \
           -C "github-actions-laravel-todo" \
           -f ~/.ssh/deploy_laravel_todo \
           -N ""
           # -N "" = pas de passphrase (nécessaire pour l'automatisation)
```

Résultat :

```
~/.ssh/deploy_laravel_todo        ← clé PRIVÉE  → GitHub Secret
~/.ssh/deploy_laravel_todo.pub    ← clé PUBLIQUE → serveur
```

### 4.2 Déployer la clé publique sur le serveur

```bash
# Méthode 1 : ssh-copy-id (si vous avez encore accès par mot de passe)
ssh-copy-id -i ~/.ssh/deploy_laravel_todo.pub -p 2222 deploy@IP_SERVEUR

# Méthode 2 : manuellement
cat ~/.ssh/deploy_laravel_todo.pub | \
  ssh -p 2222 deploy@IP_SERVEUR \
  "mkdir -p ~/.ssh && cat >> ~/.ssh/authorized_keys && chmod 600 ~/.ssh/authorized_keys"
```

### 4.3 Restreindre la clé publique dans `authorized_keys`

SSH permet d'ajouter des **options de restriction** directement dans `authorized_keys`. C'est une sécurité supplémentaire : même si la clé privée fuit, l'attaquant ne peut faire qu'une seule chose avec.

Sur le serveur, éditer `/home/deploy/.ssh/authorized_keys` :

```
# Format : options clé commentaire
command="/srv/laravel-todo/deploy.sh",no-port-forwarding,no-x11-forwarding,no-agent-forwarding,no-pty ssh-ed25519 AAAA... github-actions-laravel-todo
```

| Option | Effet |
|---|---|
| `command="..."` | Force l'exécution d'une seule commande, quoi qu'il arrive |
| `no-port-forwarding` | Interdit les tunnels TCP |
| `no-x11-forwarding` | Interdit le forwarding graphique |
| `no-agent-forwarding` | Interdit le forwarding d'agent SSH |
| `no-pty` | Interdit l'ouverture d'un terminal interactif |

Avec cette config, même si quelqu'un vole la clé privée, il ne peut exécuter **que** `deploy.sh` et rien d'autre.

---

## 5. Configurer fail2ban

`fail2ban` surveille les logs SSH et bloque automatiquement les IPs qui font trop de tentatives d'authentification échouées.

### 5.1 Installation

```bash
sudo apt install fail2ban -y
```

### 5.2 Configuration dédiée SSH

Créer `/etc/fail2ban/jail.d/sshd.conf` :

```ini
[sshd]
enabled  = true
port     = 2222          # notre port personnalisé
filter   = sshd
logpath  = /var/log/auth.log
maxretry = 3             # 3 échecs → bannissement
bantime  = 1h            # banni pendant 1 heure
findtime = 10m           # fenêtre de détection : 10 minutes
```

```bash
sudo systemctl enable fail2ban
sudo systemctl restart fail2ban

# Vérifier le statut
sudo fail2ban-client status sshd
```

---

## 6. Flux complet de la connexion sécurisée

![Flux complet de la connexion SSH sécurisée](images/03_flux_connexion.png)

Chaque étape est une barrière de sécurité indépendante. Un attaquant doit franchir toutes les étapes pour atteindre le serveur :

1. **Obtenir la clé privée** — stockée chiffrée dans GitHub Secrets, jamais en clair
2. **Passer fail2ban** — bloqué après 3 tentatives échouées
3. **Correspondre à `authorized_keys`** — signature cryptographique ED25519
4. **Respecter les restrictions** — `no-pty`, `no-forwarding`, `command=` figé
5. **`deploy.sh` est la seule action possible** — pas de shell interactif

---

## 7. GitHub Secrets — ce qui est stocké et pourquoi

![GitHub Secrets et injection dans le pipeline](images/04_github_secrets.png)

Pour ajouter les secrets via GitHub CLI :

```bash
gh secret set STAGING_SSH_KEY < ~/.ssh/deploy_laravel_todo
gh secret set STAGING_HOST --body "192.168.1.X"
gh secret set STAGING_USER --body "deploy"
gh secret set STAGING_PORT --body "2222"
```

> Les secrets sont **chiffrés au repos** dans GitHub et **masqués dans tous les logs** du pipeline. Si une étape tente d'afficher leur valeur, GitHub la remplace automatiquement par `***`.

---

## 8. Tester la connexion avant de lancer le pipeline

Avant de configurer GitHub Actions, valider la connexion manuellement :

```bash
# Tester depuis votre machine locale
ssh -i ~/.ssh/deploy_laravel_todo \
    -p 2222 \
    -o StrictHostKeyChecking=no \
    deploy@IP_SERVEUR \
    "echo 'Connexion OK'"

# Résultat attendu :
# Connexion OK
# (et rien d'autre — le shell interactif est bloqué par no-pty)
```

> Si vous avez ajouté l'option `command=` dans `authorized_keys`, la connexion exécutera `deploy.sh` automatiquement. Pour tester sans déclencher le déploiement, commentez temporairement la ligne `command=`.

---

## 9. Job CD dans le pipeline — rappel

Voici la section à ajouter dans `.github/workflows/ci.yml` :

```yaml
  deploy-staging:
    name: Deploy to staging
    runs-on: ubuntu-latest
    needs: build-test                     # attend que la CI soit verte
    if: github.ref == 'refs/heads/main' && github.event_name == 'push'

    environment:
      name: staging
      url: http://${{ secrets.STAGING_HOST }}

    steps:
      - name: Deploy via SSH
        uses: appleboy/ssh-action@v1.0.3
        with:
          host: ${{ secrets.STAGING_HOST }}
          username: ${{ secrets.STAGING_USER }}
          key: ${{ secrets.STAGING_SSH_KEY }}
          port: ${{ secrets.STAGING_PORT }}
          script: |
            cd /srv/laravel-todo
            bash deploy.sh
```

---

## 10. Checklist de sécurité SSH — récapitulatif

![Checklist sécurité SSH — Serveur et GitHub](images/05_checklist_securite.png)

---

*Cours rédigé pour le projet `laravel-todo` — BTS/NSI DevSecOps — Mars 2026*
